#include <stdarg.h>
#define STB_SPRINTF_IMPLEMENTATION
#include "stb_sprintf.h"
#define WRITE_BUFFER_CAPACITY 4096
char write_buffer[WRITE_BUFFER_CAPACITY];
void platform_write(void *buffer, size_t len);
void platform_abort(void);
int printf(const char *fmt, ...) {
  va_list args;
  va_start(args, fmt);
  int n = stbsp_vsnprintf(write_buffer, WRITE_BUFFER_CAPACITY, fmt, args);
  va_end(args);
  platform_write(write_buffer, n);
  return n;
}

#include <stdbool.h>

void run(void *ptr, int len) { platform_write(ptr, len); }

float run_float(float a, float b) {
  printf("run_float()\n");
  return a + b;
}

int run_num(int a, int b) {
  printf("run_num()\n");
  return a + b;
}

void run_array(int *arr, int len) {
  printf("run_array()\n");
  int sum = 0;

  for (int i = 0; i < len; i++) {
    sum += arr[i];
  }

  printf("sum = %d\n", sum);
}

void run_str(void *ptr, int len) {
  printf("run_str()\n");
  platform_write(ptr, len);
  platform_write("\n", 1);
}

int main(void) {
  printf("main()\n");
  return 0;
}
