clang \
    -Wall -Wextra -I. \
    --target=wasm32 -Os -fno-builtin --no-standard-libraries -Wl,--no-entry -Wl,--export=main -Wl,--export=__heap_base -Wl,--allow-undefined \
    -Wl,--export=run_num \
    -Wl,--export=run_str \
    -Wl,--export-memory \
    -Wl,--export=run_float \
    -Wl,--export=run_array \
    -o test32.wasm \
    test32.c
