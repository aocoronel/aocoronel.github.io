const decoder = new TextDecoder();

export async function instantiateWasm(
  url,
  { env = {}, imports = {}, onInstantiate = null } = {}
) {
  const container = {
    instance: null
  };

  const finalImports = {
    ...imports,

    env: {
      ...env,

      platform_write: (ptr, len) => {
        const bytes = new Uint8Array(
          container.instance.exports.memory.buffer,
          ptr,
          len
        );

        const text = decoder.decode(bytes);

        document.getElementById('log32').innerText += text;
      },

      platform_abort: () => {
        document.getElementById('log32').innerText += 'WASM abort\n';
        throw new Error('wasm abort');
      }
    }
  };

  const resp = await fetch(url);

  const { instance, module } =
    await WebAssembly.instantiateStreaming(resp, finalImports);

  container.instance = instance;

  if (onInstantiate) {
    onInstantiate(instance, module);
  }

  return instance;
}
